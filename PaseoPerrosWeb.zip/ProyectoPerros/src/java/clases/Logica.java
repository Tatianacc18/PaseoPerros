
package clases;

public class Logica {
    
    public double calcularCosto(int horas, int perros, int peque, int media, int grande){
        
        int total = 0;
        double costoTotal;
        int cantPerros = perros;
        
        if(peque > 0){
            total = total + (peque*(horas * 3000));
        }
        if(media > 0){
            total = total+(media*(horas * 5000));
        }
        if(grande > 0){
            total = total+(grande*(horas * 10000));
        }
        
        costoTotal = total - (total * 0.1);
        
        return costoTotal;
    }
}
