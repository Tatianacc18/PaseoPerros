
package com.mycompany.codificadaperros;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class codificadaPerros extends JFrame implements ActionListener {
 private JLabel lblTitulo, lblPequeño, lblMediano, lblGrande, lblHorasPaseo, lblResultado, imagen;
    private JTextField txtCantidadPequeño, txtCantidadMediano, txtCantidadGrande, txtHorasPaseo;
    private JButton btnCalcular;

    public codificadaPerros() {
        setTitle("Paseos de Perros");
        setSize(600, 300); 
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        

        
        // Título
        lblTitulo = new JLabel("PASEO PERROS");
        lblTitulo.setFont(new Font("Serif", Font.BOLD, 24));
        lblTitulo.setForeground(Color.RED);

        // Etiquetas y campos de texto
        lblPequeño = new JLabel("Pequeños:");
        lblMediano = new JLabel("Medianos:");
        lblGrande = new JLabel("Grandes:");
        lblHorasPaseo = new JLabel("Horas:");
        lblResultado = new JLabel("");

        txtCantidadPequeño = new JTextField(5);
        txtCantidadMediano = new JTextField(5);
        txtCantidadGrande = new JTextField(5);
        txtHorasPaseo = new JTextField(5);

        // Botón de cálculo
        btnCalcular = new JButton("Calcular");
        btnCalcular.addActionListener(this);

        // Panel principal
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 2));
        panel.add(lblTitulo); 
        panel.add(new JLabel("")); 
        panel.add(lblPequeño);
        panel.add(txtCantidadPequeño);
        panel.add(lblMediano);
        panel.add(txtCantidadMediano);
        panel.add(lblGrande);
        panel.add(txtCantidadGrande);
        panel.add(lblHorasPaseo);
        panel.add(txtHorasPaseo);
        panel.add(btnCalcular);
        panel.add(lblResultado);

        add(panel);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnCalcular) {
            try {
                int cantidadPequeño = Integer.parseInt(txtCantidadPequeño.getText());
                int cantidadMediano = Integer.parseInt(txtCantidadMediano.getText());
                int cantidadGrande = Integer.parseInt(txtCantidadGrande.getText());
                double horasPaseo = Double.parseDouble(txtHorasPaseo.getText());

                double costoTotal = (cantidadPequeño * 3000 + cantidadMediano * 5000 + cantidadGrande * 10000) * horasPaseo;

                lblResultado.setText("Costo total: $" + costoTotal);
            } catch (NumberFormatException ex) {
                lblResultado.setText("Por favor, ingrese valores válidos.");
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
           codificadaPerros ventana = new codificadaPerros();
            ventana.setVisible(true);
        });
    }
}